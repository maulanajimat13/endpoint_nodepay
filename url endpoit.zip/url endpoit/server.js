const express = require('express');
const app = express();
const port = 3000;

// Middleware untuk parsing JSON
app.use(express.json());

// Endpoint untuk ping
app.post('/api/network/ping', (req, res) => {
  const { id, timestamp, version } = req.body;

  // Validasi data
  if (!id || !timestamp || !version) {
    return res.status(400).json({ error: 'Invalid request data' });
  }

  console.log(`Ping received from ID: ${id}`);
  res.status(200).json({ status: 'success', message: 'Ping received' });
});

// Jalankan server
app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});
